# Sales Performance Analysis with ML

A web-based sales performance analysis tool that uses machine learning to provide insights into sales data, predict future sales, and detect anomalies.

## Features

- User Authentication (Register/Login)
- Interactive Dashboard
- Sales Trend Analysis
- ML-powered Sales Predictions
- Anomaly Detection
- Product Performance Analysis
- Real-time Data Visualization

## Tech Stack

- Python 3.8+
- Flask
- SQLAlchemy
- scikit-learn
- Plotly.js
- Bootstrap 5
- SQLite

## Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd sales-performance-analysis
```

2. Create a virtual environment:
```bash
python -m venv venv
```

3. Activate the virtual environment:
- Windows:
```bash
venv\Scripts\activate
```
- Unix/MacOS:
```bash
source venv/bin/activate
```

4. Install dependencies:
```bash
pip install -r requirements.txt
```

## Running the Application

1. Make sure your virtual environment is activated

2. Run the Flask application:
```bash
python app.py
```

3. Open your browser and navigate to:
```
http://localhost:5000
```

## Usage

1. Register a new account or login with existing credentials
2. Navigate to the dashboard to view sales analytics
3. Explore different visualizations and ML insights
4. Monitor real-time sales performance

## Security Notes

- All passwords are hashed before storage
- Session management is handled securely
- CSRF protection is enabled
- Input validation is implemented

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details. 